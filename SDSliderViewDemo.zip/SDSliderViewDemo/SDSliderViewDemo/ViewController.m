//
//  ViewController.m
//  SDSliderViewDemo
//
//  Created by songjc on 16/10/1.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import "ViewController.h"
#import "SDSilderView.h"
@interface ViewController ()<SDSilderViewDelegate>

@property(nonatomic,strong)UILabel *myLabel;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"主背景.png"]];
    SDSilderView *silderView = [SDSilderView initWithPosition:CGPointMake(100, 100) viewRadius:100];
    
    [self.view addSubview: silderView];
    
    _myLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 400, self.view.frame.size.width, 40)];
    
    _myLabel.font = [UIFont systemFontOfSize:20];
    
    _myLabel.textColor = [UIColor whiteColor];
    
    silderView.delegate = self;

    _myLabel.textAlignment = NSTextAlignmentCenter;
    
    _myLabel.text = [NSString stringWithFormat:@"%.2f",silderView.value];
    
    [self.view addSubview:_myLabel];
    
    //给通知中心添加观察者
//    
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changNewValue:) name:KSDSilderViewNewValue object:nil];
}
#pragma mark ----代理 ---

-(void)silderViewNewChangeValue:(float)newChangeValue{


    _myLabel.text = [NSString stringWithFormat:@"%.2f",newChangeValue];



}


#pragma mark ----通知 ----
//-(void)changNewValue:(NSNotification *)sender{
//
//    NSNumber * newChangeValue = sender.object;
//    _myLabel.text = [NSString stringWithFormat:@"%.2f",[newChangeValue floatValue]];
//
//}
//
//-(void)dealloc{
//
//    [[NSNotificationCenter defaultCenter] removeObserver:self];
//
//}

@end
